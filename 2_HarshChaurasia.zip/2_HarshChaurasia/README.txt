Hi , I am Harsh Chaurasia . Desired intern @BUGSMIRROR .

So I have developed this Backend API using GO. I would mention I have used GORILLA MUX to configure to the HTTTP SERVER. No third party packages have been used.
In my database I have took up attributes like :-
login
register
submitcomplaints
getallcomplaintsforusers
getallcomplaintsforADMIN
viewcomplaint
resolveComplaint

I have previously worked on GOlang but from a long period of time I was not much active in GOlang but still i have given my best to write code as clean  and as organised as possible. I am believe in being a Pro-active Learner and will improve with time.

SINCERELY 
HARSH CHAURASIA